﻿using Microsoft.AspNetCore.Mvc;
using ödev3.Data;
using ödev3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ödev3.ViewComponents
{
    public class CategoryMenuViewComponent : ViewComponent
    {
        Context c = new Context();
       public IViewComponentResult Invoke()
        {
            if(RouteData.Values["action"].ToString()=="Index")
            ViewBag.SelectedCategory = RouteData?.Values["id"];
            return View(c.Categories.ToList());
        }
    }
}
