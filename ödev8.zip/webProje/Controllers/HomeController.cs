﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using webProje.Data;
using webProje.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace webProje.Controllers
{
    public class HomeController : Controller
    {
        ApplicationDbContext c = new ApplicationDbContext();

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index(int? id)
        {
            var movies = c.Movies.ToList();
            if (id != null)
            {
                movies = movies.Where(i => i.CategoryId == id).ToList();
            }
            return View(movies);
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult authenticationPanel()
        {
            return View();
        }
        public IActionResult Details(int id)
        {
            var movies = c.Movies.ToList();
            var movie = movies.Where(i => i.Id == id).First();

            return View(movie);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
