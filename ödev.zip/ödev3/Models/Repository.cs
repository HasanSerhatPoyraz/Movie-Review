﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ödev3.Models
{
    public static class Repository 
    {
        private static List<Movie> _movies = null;

        static Repository()
        {
            _movies = new List<Movie>()
            {
                new Movie(){Id=1, Name="Shazam", Description="Shazam", ImageUrl="1.jpg" },
                new Movie(){Id=2, Name="Amazing Grace", Description="Amazing Grace", ImageUrl="1.jpg" },
                new Movie(){Id=3, Name="High Life", Description="High Life", ImageUrl="1.jpg" },
                new Movie(){Id=4, Name="BillBoard", Description="BillBoard", ImageUrl="1.jpg" },
                new Movie(){Id=5, Name="Stormboy", Description="Stormboy", ImageUrl="1.jpg" }
            };
        }

        public static List<Movie> Movies
        {
            get
            {
                return _movies;
            }

        }

        public static void AddMovie(Movie entity)
        {
            _movies.Add(entity);
        }

        public static Movie GetById(int id)
        {
            return _movies.FirstOrDefault(i => i.Id == id);
        }
    }
}
